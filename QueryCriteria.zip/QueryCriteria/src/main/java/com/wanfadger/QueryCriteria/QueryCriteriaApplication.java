package com.wanfadger.QueryCriteria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QueryCriteriaApplication {

	public static void main(String[] args) {
		SpringApplication.run(QueryCriteriaApplication.class, args);
	}

}
