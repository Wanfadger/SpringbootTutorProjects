package com.wanfadger.QueryCriteria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QueryCriteriaApplicationTests {

	@Test
	void contextLoads() {
	}

}
